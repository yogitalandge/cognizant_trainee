package com.cts.training.usermicroservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.usermicroservice.Repository.custom.IUserDetailsRepositoryCustom;
import com.cts.training.usermicroservice.entity.User;

public interface IUserRepository extends JpaRepository<User, Integer>,IUserDetailsRepositoryCustom {

	List<User>findByUsername(String username);
}
