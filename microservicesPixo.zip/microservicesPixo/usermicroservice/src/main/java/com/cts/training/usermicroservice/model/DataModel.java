package com.cts.training.usermicroservice.model;

import java.util.List;

import com.cts.training.usermicroservice.entity.User;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter

public class DataModel {

	public List<User> user;
}
