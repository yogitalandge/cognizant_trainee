package com.cts.training.usermicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.usermicroservice.Repository.IAuthorityRepository;
import com.cts.training.usermicroservice.Repository.IUserRepository;
import com.cts.training.usermicroservice.entity.Roles;
import com.cts.training.usermicroservice.entity.User;
import com.cts.training.usermicroservice.model.UserInput;
import com.cts.training.usermicroservice.model.UserModel;
import com.cts.training.usermicroservice.model.UserOutput;

import lombok.Getter;



// @Component
@Service
public class UserServiceImpl implements IUserService {



	@Autowired
	private IUserRepository userRepository;
	@Autowired
	private IAuthorityRepository authorityRepository;
	
	
	public List<User> findAllUsers() {
		List<User> records=this.userRepository.findAll();
		return records;
	}

	@Override
	public  User findUserById(Integer userId) {
		// TODO Auto-generated method stub
		//return this.userRepository.findById(userId);
		
		Optional<User> record= this.userRepository.findById(userId);
		User user= new User();
		if(record.isPresent())
			user=record.get();
		return user;
	}

		

	//@Override
//	public boolean deleteUser(Integer userId) {
		// TODO Auto-generated method stub
	//	this.userRepository.deleteById(userId);
		//return true;
//	}
	public boolean saveuser(UserModel user) {
		User data = new User();
		
		data.setUsername(user.getUsername());
		data.setFirstName(user.getFirstName());
		data.setLastName(user.getLastName());
		data.setEmail(user.getEmail());
		//data.setDob(user.getDob());
		data.setPassword("{noop}" + user.getPassword());
		data.setProfilepic(user.getProfilepic());
		data.setEnabled(true);
		this.userRepository.save(data);

		// add authority
		Roles role = new Roles(user.getUsername(), "ROLE_USER");
		this.authorityRepository.save(role);
		return true;
		
		}
	

		public void updateuser(UserOutput user) {
		User data = new User();
		//Authorities auth = new Authorities();
		//auth.setUsername(user.getUsername());
		//auth.setAuthority("ROLE_USER");
		data.setUserId(user.getUserId());
		data.setUsername(user.getUsername());
		data.setFirstName(user.getFirstName());
		data.setLastName(user.getLastName());
		data.setEmail(user.getEmail());
		//data.setDob(user.getDob());
		data.setPassword(user.getPassword());
		data.setProfilepic(user.getProfilepic());
		data.setEnabled(true);
		this.userRepository.save(data);
		}


		@Override
		public boolean updateUser(User user) {
			// TODO Auto-generated method stub
			this.userRepository.save(user);
			return true;
		}

		@Override
		public boolean deleteUser(Integer userId) {
			// TODO Auto-generated method stub
			this.userRepository.deleteById(userId);
			return true;
		}

		@Override
		public boolean addUser(User user) {
			// TODO Auto-generated method stub
			this.userRepository.save(user);
			return true;
		}

		
/*
		@Override
		public User addAllUsers(UserModel user) {
			// TODO Auto-generated method stub
			User user = new User();
			
			user.setUsername(usermodel.getUsername());
			user.setFirstName(usermodel.getFirstName());
			user.setLastName(usermodel.getLastName());
			user.setEmail(usermodel.getEmail());
			
			user.setPassword(usermodel.getPassword());
			user.setProfilepic(usermodel.getProfilepic());
			user.setEnabled(true);
			this.userRepository.save(user);
			return user;
		}

	*/	
 
		
		}


