package com.cts.training.usermicroservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity 
@Table(name = "authorities")
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Authorities {
	
	@Column
	private String username;
	@Column
	private String authority;
	
	

}