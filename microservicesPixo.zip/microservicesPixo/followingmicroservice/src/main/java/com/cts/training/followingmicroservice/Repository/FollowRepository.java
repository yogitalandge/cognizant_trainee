package com.cts.training.followingmicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.followingmicroservice.entity.Follow;

public interface FollowRepository extends JpaRepository<Follow, Integer>{

}
