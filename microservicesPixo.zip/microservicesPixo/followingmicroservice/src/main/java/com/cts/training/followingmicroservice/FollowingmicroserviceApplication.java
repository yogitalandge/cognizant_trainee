package com.cts.training.followingmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FollowingmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FollowingmicroserviceApplication.class, args);
	}

}
