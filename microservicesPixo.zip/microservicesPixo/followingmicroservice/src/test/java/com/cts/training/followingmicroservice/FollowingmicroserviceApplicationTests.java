package com.cts.training.followingmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FollowingmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
