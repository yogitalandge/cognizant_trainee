package com.cts.training.mediamicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MediamicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediamicroserviceApplication.class, args);
	}

}
