package com.cts.training.mediamicroservice.model;

import java.util.List;

import com.cts.training.mediamicroservice.entity.Media;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MediaModel {

	
	private List<Media> medialist;
}
