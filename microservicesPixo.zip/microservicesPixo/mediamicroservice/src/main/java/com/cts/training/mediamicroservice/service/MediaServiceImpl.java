package com.cts.training.mediamicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.mediamicroservice.Repository.IMediaRepository;
import com.cts.training.mediamicroservice.entity.Media;
import com.cts.training.mediamicroservice.model.MediaData;
import com.cts.training.mediamicroservice.model.MediaDataModel;
import com.cts.training.mediamicroservice.model.MediaModel;






// @Component
@Service
public class MediaServiceImpl implements IMediaService {

	
	
	@Autowired
	private IMediaRepository mediaRepository;
	
	@Override
	public List<Media> findAllMedia() {
		// add additional logic
		List<Media> records=this.mediaRepository.findAll();
		return records;
	}

	@Override
	public Media findMediaById(Integer mediaId) {
		// TODO Auto-generated method stub
		//return this.userRepository.findById(userId);
		
		Optional<Media> record= this.mediaRepository.findById(mediaId);
		Media media = new Media();
		if(record.isPresent())
			media=record.get();
		return media;
	}

	@Override
	public boolean addMedia(Media media) {
		// TODO Auto-generated method stub
		 this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean updateMedia(Media media) {
		// TODO Auto-generated method stub
		Media data = new Media();
		data.setUserId(media.getUserId());
		//data.setId(media.getId());
		data.setTitle(media.getTitle());
		data.setDescription(media.getDescription());
		data.setTag(media.getTag());
		data.setMimeType(media.getMimeType());
		data.setFileUrl(media.getFileUrl());
		this.mediaRepository.save(data);
		// this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean deleteMedia(Integer mediaId) {
		// TODO Auto-generated method stub
		 this.mediaRepository.deleteById(mediaId);
		return true;
	}

	@Override
	public boolean saveMedia(MediaDataModel media) {
		// TODO Auto-generated method stub
   Media  data = new Media();
		data.setUserId(media.getUserId());
		data.setTitle(media.getTitle());
		data.setDescription(media.getDescription());
		data.setMimeType(media.getMimeType());
		data.setTag(media.getTag());
		//data.setDob(user.getDob());
		//data.setPassword("{noop}" + user.getPassword());
		data.setFileUrl(media.getFileUrl());
		//data.setEnabled(true);
		this.mediaRepository.save(data);
		return true;
	}
}

		
		
		
	