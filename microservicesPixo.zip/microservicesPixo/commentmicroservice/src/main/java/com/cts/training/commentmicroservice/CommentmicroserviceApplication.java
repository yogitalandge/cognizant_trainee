package com.cts.training.commentmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommentmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommentmicroserviceApplication.class, args);
	}

}
