package com.cts.training.mediaplumbingmicroservice.feignproxy;



import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaplumbingmicroservice.model.MediaDataModel;


@FeignClient(name = "api-gateway", url="http://localhost:8765/") //, decode404 = true)
@RibbonClient(name = "media-services")
@Service
public interface IMediaMicroserviceProxy {

//	@GetMapping("media-service/media/{mediaId}")
//public ResponseEntity<MediaPlumbing> mediaDetail(@PathVariable Integer mediaId);

	@PostMapping(value = "/media-services/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file);
	
	@PostMapping(value = "/media-services/mediadata")
	public boolean saveData(@RequestBody MediaDataModel media);
}





