package com.cts.training.mediaplumbingmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaplumbingmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
