package com.cts.training.actionmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActionmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActionmicroserviceApplication.class, args);
	}

}
