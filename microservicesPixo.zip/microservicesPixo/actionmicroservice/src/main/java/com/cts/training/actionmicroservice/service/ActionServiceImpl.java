package com.cts.training.actionmicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.actionmicroservice.Repository.IActionRepository;
import com.cts.training.actionmicroservice.entity.Action;







// @Component
@Service
public class ActionServiceImpl implements IActionService {

	
	
	@Autowired
	private IActionRepository actionRepository;
	
	@Override
	public List<Action> findAllAction() {
		// add additional logic
		return this.actionRepository.findAll();
	}

	@Override
	public Action findActionById(Integer actionId) {
		// TODO Auto-generated method stub
		//return this.userRepository.findById(userId);
		
		Optional<Action> record= this.actionRepository.findById(actionId);
		Action action = new Action();
		if(record.isPresent())
			action=record.get();
		return action;
	}

	@Override
	public boolean addAction(Action action) {
		// TODO Auto-generated method stub
		 this.actionRepository.save(action);
		return true;
	}

	@Override
	public boolean updateAction(Action action) {
		// TODO Auto-generated method stub
		this.actionRepository.save(action);
		return true;
	}

	@Override
	public boolean deleteAction(Integer actionId) {
		// TODO Auto-generated method stub
		 this.actionRepository.deleteById(actionId);
		return true;
	}

}
