package com.cts.training.blockedusermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockedusermicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
