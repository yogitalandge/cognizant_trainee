import { ɵLocaleDataIndex } from '@angular/core';

export class UserRegistrationDetails{


    userId:number;
    username:string;
    password:string;
    firstName:string;
    lastName:string;
    email:string;
    dob:ɵLocaleDataIndex;
    profilepic:string;


    constructor(userId:number,
        username:string,
        password:string,
        firstName:string,
        lastName:string,
        email:string,
        dob:ɵLocaleDataIndex,
        profilepic:string)
        {
            this.username=username;
            this.password=password;
            this.email=email;
            this.lastName=lastName;
            this.firstName=firstName;
            this.dob=dob;
            this.profilepic=profilepic;
        }

}