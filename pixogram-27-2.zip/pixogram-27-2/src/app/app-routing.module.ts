import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { SearchReasultComponent } from './search-reasult/search-reasult.component';
import { LoginComponent } from './login/login.component';

import { AuthGuardService } from './services/auth-guard.service';
import { ErrorComponent } from './error/error.component';

import { MediaUpdateComponent } from './media/media-update/media-update.component';

import { MediaListComponent } from './media/media-list/media-list.component';
import { LogoutComponent } from './Account/logout/logout.component';
import { SingleMediaComponent } from './media-update/single-media/single-media.component';
import { MultipleMediaComponent } from './media-update/multiple-media/multiple-media.component';
import { FollowersComponent } from './Myfollows/followers/followers.component';
import { FollowingsComponent } from './Myfollows/followings/followings.component';
import { ProfileUpdateComponent } from './Account/profile-update/profile-update.component';
import { AccDisplayComponent } from './Account/acc-display/acc-display.component';
import { RegisterComponent } from './register/register.component';


const routes: Routes = [
  { path:"", redirectTo : "home", pathMatch: "full"},
  { path:"home", component: HomeComponent},
  { path:"contactus", component: ContactComponent},
  { path:"aboutus", component: AboutComponent},
  { path:"login", component: LoginComponent},
  {path:"profile",component : ProfileUpdateComponent},
  {path:"signUp",component : RegisterComponent},
 
 
  // add a fallback mapping
  {path:"accdisplay",component:AccDisplayComponent },
  {path:"followings",component :FollowingsComponent},
  {path:"followers",component :FollowersComponent},
  {path:"singlemedia",component : SingleMediaComponent},
  {path:"multiplemedia",component : MultipleMediaComponent},
  { path:"media", component: MediaListComponent, canActivate : [AuthGuardService]},
 
  { path:"media-update/:mediaId", component: MediaUpdateComponent, canActivate : [AuthGuardService]},
 {path:"logout",component:LogoutComponent},
  // <url>/:<name by which data is accessed>
  { path:"search/:searchText", component:  SearchReasultComponent},
  { path:"**", component: ErrorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
