import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { UserRegistrationService } from '../services/user-registration.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 
form : FormGroup;
constructor(Formbuilder:FormBuilder,public router:Router,public auth :AuthenticationService,private userService:UserRegistrationService) {
  this.form=Formbuilder.group({



    "userId": new FormControl(""),
    "username": new FormControl("",Validators.required),
    "password": new FormControl("",Validators.required),
    "email": new FormControl("",[Validators.required,Validators.email]),
    "firstName": new FormControl("",Validators.required),
    "lastName": new FormControl("",Validators.required),
    "dob": new FormControl("",Validators.required),
    "profilepic": new FormControl("",Validators.required),
  });
}

 
register(): void{
  
  this.userService.addNewUser(this.form.value).subscribe(data=>{
    alert("Registered successfully...!!!")
    this.login();
  })
}
  
 login(): void{
   this.router.navigate(['login'])
 }  
 
 
  ngOnInit() {
  }
  onSubmit(){
    alert(JSON.stringify(this.form.value));
  }

}
