import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MediaDataService } from 'src/app/services/data/media-data.service';
import { Media } from 'src/app/model/media.model';

@Component({
  selector: 'app-media-update',
  templateUrl: './media-update.component.html',
  styleUrls: ['./media-update.component.css']
})
export class MediaUpdateComponent implements OnInit {
 
  // dependecy on Media Data Service
  constructor() { 
  
  }

  ngOnInit() {
   
  }



  
}

