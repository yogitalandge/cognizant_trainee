import { Component, OnInit } from '@angular/core';
import { MediaDataService } from 'src/app/services/data/media-data.service';
import { Router } from '@angular/router';
import { Media } from 'src/app/model/media.model';

@Component({
  selector: 'app-media-list',
  templateUrl: './media-list.component.html',
  styleUrls: ['./media-list.component.css']
})
export class MediaListComponent implements OnInit {

 
 
  // dependent on media-data-service
  constructor() { 

  }





  ngOnInit() {
    // load data from server on initialization
    // need to call getAllMedia() method of MediaDataService
    // this.media = this.mediaService.getAllMedia();
    // response : response data from server : Array of media
   
  }

}