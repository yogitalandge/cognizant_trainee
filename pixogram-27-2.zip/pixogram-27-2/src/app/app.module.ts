import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import{FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { MenuComponent } from './menu/menu.component';
import { SearchReasultComponent } from './search-reasult/search-reasult.component';
import { LoginComponent } from './login/login.component';
import { ErrorComponent } from './error/error.component';





import { HttpClientModule } from '@angular/common/http';

import { MediaListComponent } from './media/media-list/media-list.component';

import { MediaUpdateComponent } from './media/media-update/media-update.component';
import { RegisterComponent } from './register/register.component';
import { SingleMediaComponent } from './media-update/single-media/single-media.component';
import { MultipleMediaComponent } from './media-update/multiple-media/multiple-media.component';
import { ProfileUpdateComponent } from './Account/profile-update/profile-update.component';
import { BlockedUserComponent } from './Account/blocked-user/blocked-user.component';
import { NewsFeedComponent } from './Account/news-feed/news-feed.component';
import { FollowersComponent } from './Myfollows/followers/followers.component';
import { FollowingsComponent } from './Myfollows/followings/followings.component';
import { LogoutComponent } from './Account/logout/logout.component';
import { SearchComponent } from './Account/search/search.component';
import { AccDisplayComponent } from './Account/acc-display/acc-display.component';
import { from } from 'rxjs';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    MenuComponent,
    SearchReasultComponent,
    LoginComponent,

    ErrorComponent,
   
    MediaListComponent,
  
    MediaUpdateComponent,
    RegisterComponent,
    SingleMediaComponent,
    MultipleMediaComponent,
    ProfileUpdateComponent,
    BlockedUserComponent,
    NewsFeedComponent,
    FollowersComponent,
    FollowingsComponent,
    LogoutComponent,
    SearchComponent,
    AccDisplayComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
