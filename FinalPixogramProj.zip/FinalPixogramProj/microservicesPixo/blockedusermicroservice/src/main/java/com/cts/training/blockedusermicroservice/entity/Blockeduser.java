package com.cts.training.blockedusermicroservice.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity 
@Table(name = "blockeduser")
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Blockeduser {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer blockeduserId;
	@Column
	private Integer userId;
	@Column
	private LocalDateTime createdOn;
	@Column
	private LocalDateTime updatedOn;
	
	
	
}