package com.cts.training.usermicroservice.Controller;

import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.usermicroservice.Repository.IUserRepository;
import com.cts.training.usermicroservice.entity.User;
import com.cts.training.usermicroservice.model.ResponseData;
import com.cts.training.usermicroservice.model.UserInput;
import com.cts.training.usermicroservice.model.UserModel;
import com.cts.training.usermicroservice.service.IUserService;
import com.cts.training.usermicroservice.service.StorageService;



@RestController
@CrossOrigin("*")
public class LoginController {

	@Autowired
	public IUserService userService;
	@Autowired
	private StorageService storageService;
	@Autowired
	private IUserRepository userRepository;
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	// testing end-point
	@GetMapping("/login")
	public ResponseEntity<ResponseData>login(HttpServletRequest request)
	{
		String authorization = request.getHeader("Authorization");
		String[] values = null;
		
		if (authorization != null && authorization.startsWith("Basic")) {
		    // Authorization: Basic base64credentials
		    String base64Credentials = authorization.substring("Basic".length()).trim();
		    byte[] credDecoded = Base64.getDecoder().decode(base64Credentials);
		    String credentials = new String(credDecoded, StandardCharsets.UTF_8);
		    // credentials = username:password
		    values = credentials.split(":", 2);
		}
		logger.info("Logged in..");
		logger.info(values[0]);
		logger.info(values[1]);
		
		//logger.info(principal.getName());
		 User user = this.userRepository.findByUsername(values[0]).get(0);
	        logger.info("User : " + user);
		//User user = this.userRepository.findByUsername(principal.getName()).get(0);
		//logger.info("User :"+ user);

		ResponseData data = new ResponseData("Welcome!!!", System.currentTimeMillis(),user.getUserId());

		//final MultiValueMap<String, String> header = new LinkedMultiValueMap<String, String>();
		//header.add("", "");
		ResponseEntity<ResponseData> response = 
					new ResponseEntity<ResponseData>(data, HttpStatus.OK);	
		return response;
			}
/*	@GetMapping("")
	public ResponseEntity<List<UserModel>> findUserNames(){
		List<UserModel> userNames =this.userService.findUsernames();
		ResponseEntity<List<UserModel>> response = 
				new ResponseEntity<List<UserModel>> (userNames, HttpStatus.OK);
		return response;
	}
	*/
	
	@PostMapping("/register")
	public ResponseEntity<UserModel>  saveuser(@RequestParam("file") MultipartFile file,
			
			@RequestParam("profilepic") String profilepic,
			@RequestParam("username") String username,
			@RequestParam("password") String password,
			@RequestParam("lastName") String lastName,
			@RequestParam("firstName") String firstName,
			@RequestParam("email") String email)
	{
		logger.info(username+""+password+""+firstName+""+lastName+""+email);
		UserModel user = new UserModel(username,password,firstName,lastName,email,profilepic);
		this.userService.saveuser(user);
		this.storageService.store(file);
		ResponseEntity<UserModel> response = 
				new ResponseEntity<UserModel>(user, HttpStatus.OK);
		return response;
	}
/*	@PostMapping("/user") // POST HTTP VERB
	public ResponseEntity<User> save(@RequestParam("file") MultipartFile file,
			@RequestParam("userId") Long userId,
			@RequestParam("url")String url,
			@RequestParam("firstName")String firstName,
			@RequestParam("lastName")String lastName,
			@RequestParam("email")String email,
			@RequestParam("username")String username){
		User user = new User();
		if(!this.userService.addUser(user));
		throw new RuntimeException("could not add new record");
		
       this.storageService.store(file);
  logger.info("pic uploaded successfully" + file.getOriginalFilename() + "!");
  ResponseEntity<User> response = 
			new ResponseEntity<User>(user, HttpStatus.OK);

	return response;
	}*/
}
