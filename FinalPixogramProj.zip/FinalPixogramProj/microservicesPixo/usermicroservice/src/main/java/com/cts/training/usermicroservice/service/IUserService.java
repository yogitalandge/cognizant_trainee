package com.cts.training.usermicroservice.service;

import java.util.List;
import java.util.Optional;

import com.cts.training.usermicroservice.entity.User;
import com.cts.training.usermicroservice.model.SearchedUserModelList;
import com.cts.training.usermicroservice.model.UserInput;
import com.cts.training.usermicroservice.model.UserModel;



public interface IUserService {

	
	
 	List<User> findAllUsers();
User findUserById(Integer userId);
boolean addUser(User user);
	boolean updateUser(User user);
	boolean deleteUser(Integer userId);
 public boolean saveuser(UserModel user);
 public SearchedUserModelList searchUsers(String searchString);
	
//User addAllUsers(UserModel user);

	
}
