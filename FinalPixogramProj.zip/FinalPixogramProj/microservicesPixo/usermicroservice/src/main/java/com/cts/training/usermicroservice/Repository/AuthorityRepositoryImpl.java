package com.cts.training.usermicroservice.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cts.training.usermicroservice.entity.Roles;

@Repository
@Transactional
public class AuthorityRepositoryImpl implements IAuthorityRepository{

	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	public void save(Roles role) {
		this.em.persist(role);
		
	}
}
