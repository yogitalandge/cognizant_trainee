package com.cts.training.actionmicroservice.service;

import java.util.List;
import java.util.Optional;

import com.cts.training.actionmicroservice.entity.Action;
import com.cts.training.actionmicroservice.model.CountOfActionsModel;



public interface IActionService {

	
	


	List<Action> findAllActions();
	Optional<Action> findActionById(Integer actionId);
	boolean addAction(Action action);
	boolean updateAction(Action action);
	public CountOfActionsModel getLikesByMediaId(Integer actionId);
}
