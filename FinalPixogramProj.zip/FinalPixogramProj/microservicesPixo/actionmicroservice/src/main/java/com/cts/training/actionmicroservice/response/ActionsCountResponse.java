package com.cts.training.actionmicroservice.response;

import com.cts.training.actionmicroservice.model.CountOfActionsModel;

public class ActionsCountResponse {
	
	public CountOfActionsModel actiondata;
}
