
package com.cts.training.actionmicroservice.model;

import java.util.List;

import com.cts.training.actionmicroservice.entity.Action;

import lombok.Getter;
import lombok.Setter;




@Getter
@Setter
public class ActionListModel {
	
	List<Action> actions;
}
