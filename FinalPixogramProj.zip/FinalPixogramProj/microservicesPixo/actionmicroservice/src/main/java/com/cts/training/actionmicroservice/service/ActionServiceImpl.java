package com.cts.training.actionmicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.actionmicroservice.Repository.IActionRepository;
import com.cts.training.actionmicroservice.custom.CustomActionRepository;
import com.cts.training.actionmicroservice.entity.Action;
import com.cts.training.actionmicroservice.model.CountOfActionsModel;







// @Component
@Service
public class ActionServiceImpl implements IActionService {

	
	
	@Autowired
	private IActionRepository actionRepository;
	
	
	@Autowired
	private CustomActionRepository customActionRepository;
	
	@Override
	public List<Action> findAllActions() {
		// TODO Auto-generated method stub
		return this.actionRepository.findAll();
		//return null;
	}

	@Override
	public Optional<Action> findActionById(Integer actionId) {
		// TODO Auto-generated method stub
		//Action action = new Action();
		Optional<Action> action = this.actionRepository.findById(actionId);
		return action;
		//return null;
	}

	@Override
	public boolean updateAction(Action action) {
		// TODO Auto-generated method stub
		//return this.actionRepository.save(action);
		this.actionRepository.save(action);
		return false;
	}

	@Override
	public boolean addAction(Action action) {
		// TODO Auto-generated method stub
		//return this.actionRepository.save(action);
		this.actionRepository.save(action);
		return false;
	}

	@Override
	public CountOfActionsModel getLikesByMediaId(Integer actionId) {
	
		CountOfActionsModel count = this.customActionRepository.getLikesAndDislikes(actionId);
		return count;
	}


	

}
