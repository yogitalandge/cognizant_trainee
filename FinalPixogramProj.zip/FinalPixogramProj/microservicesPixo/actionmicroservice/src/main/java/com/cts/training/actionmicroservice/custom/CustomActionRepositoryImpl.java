package com.cts.training.actionmicroservice.custom;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cts.training.actionmicroservice.model.CountOfActionsModel;



@Repository
public class CustomActionRepositoryImpl implements CustomActionRepository {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@PersistenceContext
	private EntityManager entityManager;


	
	@Override
	public CountOfActionsModel getLikesAndDislikes(Integer actionId) {
												 					
		TypedQuery<Long> likesQuery = entityManager.createQuery("SELECT COUNT(*) FROM Action a WHERE a.mediaId=:actionId AND a.status=true",Long.class);
		
		likesQuery.setParameter("actionId", actionId);
		
		TypedQuery<Long> dislikesQuery = entityManager.createQuery("SELECT COUNT(*) FROM Action a WHERE a.mediaId=:actionId AND a.status=false",Long.class);
		
		dislikesQuery.setParameter("actionId", actionId);
		
		Long count = (long) likesQuery.getSingleResult();
		logger.info(" likes count :" +count);
		Long count1 = (long) dislikesQuery.getSingleResult();
		logger.info("dis likes count :" +count1);
		Integer likes = Math.toIntExact(count);
		Integer dislikes  = Math.toIntExact(count1);
		CountOfActionsModel result = new CountOfActionsModel(likes, dislikes);
		return result;
	}
	
	
}
