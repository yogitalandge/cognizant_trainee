package com.cts.training.actionmicroservice.custom;

import com.cts.training.actionmicroservice.model.CountOfActionsModel;

public interface CustomActionRepository {

	public CountOfActionsModel getLikesAndDislikes(Integer mediaId);
	
}
