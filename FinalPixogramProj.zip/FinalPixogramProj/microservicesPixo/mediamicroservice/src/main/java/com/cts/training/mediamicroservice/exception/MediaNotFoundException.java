package com.cts.training.mediamicroservice.exception;

public class MediaNotFoundException extends RuntimeException{

	
	public MediaNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
