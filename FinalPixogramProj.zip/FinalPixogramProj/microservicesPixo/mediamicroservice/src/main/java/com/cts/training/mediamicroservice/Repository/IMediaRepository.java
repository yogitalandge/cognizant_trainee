package com.cts.training.mediamicroservice.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.mediamicroservice.entity.Media;

public interface IMediaRepository extends JpaRepository<Media, Integer> {
	
	

	List<Media> findByUserId(Integer userId);

}
