package com.cts.training.followingmicroservice.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity 
@Table(name = "follow")
public class Follow implements Serializable{
	

	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer userId;
	@Id
	private Integer followerId;
	
	@Column
	@CreationTimestamp
	private LocalDateTime createdOn;
	@Column
	@UpdateTimestamp
	private LocalDateTime updatedOn;
	
	
/*	public class Follow implements Serializable {
		
		/**
		 * 
		 
		private static final long serialVersionUID = 1L;

		@Id
		private Integer userId;// ~other
		
		@Id
		private Integer followerId;// ~mine
	}
	
*/
}