package com.cts.training.mediaplumbingmicroservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaplumbingmicroservice.feignproxy.IActionServiceProxy;
import com.cts.training.mediaplumbingmicroservice.feignproxy.ICommentServiceProxy;
import com.cts.training.mediaplumbingmicroservice.feignproxy.IMediaMicroserviceProxy;
import com.cts.training.mediaplumbingmicroservice.model.CommentsNumberModel;
import com.cts.training.mediaplumbingmicroservice.model.MediaData;
import com.cts.training.mediaplumbingmicroservice.model.MediaDataModel;
import com.cts.training.mediaplumbingmicroservice.model.MediaDetailsModel;
import com.cts.training.mediaplumbingmicroservice.model.MediaModel;
import com.cts.training.mediaplumbingmicroservice.response.GalleryDisplayResponse;

@CrossOrigin("*")
@RestController
public class MediaPlumbingController {

	@Autowired
	private IMediaMicroserviceProxy proxy;


	@Autowired
	private IActionServiceProxy actionServiceProxy;
	
	@Autowired
	private ICommentServiceProxy commentServiceProxy;

	private final String MEDIA_URL = "http://localhost:9094";
  Logger logger= LoggerFactory.getLogger(this.getClass());
 
	
	@PostMapping(value = "/media") // POST HTTP VERB
	public void post(@RequestParam("file") MultipartFile file,
			@RequestParam("userId") String userId,
			@RequestParam("mimeType")String mimeType,
			@RequestParam("fileUrl")String fileUrl,
			@RequestParam("title")String title,
			@RequestParam("description")String description, 
			@RequestParam("tag")String tag)
	{
 logger.info("userId"+userId+ ""+fileUrl+ ""+mimeType+""+title+""+description+""+tag+"");
		//User user = new User();
		MediaDataModel media =new MediaDataModel(Integer.parseInt(userId), title, description, mimeType, tag, fileUrl);
 // ResponseEntity<MediaPlumbingData> response = 
			//new ResponseEntity<MediaPlumbingData>( HttpStatus.OK);
		
			boolean b = this.proxy.saveData(media);
			boolean a = this.proxy.save(file);
			
	}
	
/*	@GetMapping("/media/{userId}")
	public ResponseEntity<List<MediaDataModel>> userMedia(@PathVariable Integer userId)
	{
		ResponseEntity<List<MediaDataModel>> response= this.proxy.getMediaByUserId(userId);
		return response;
	}
	*/
	
	//comment code
	@GetMapping("/media/{userId}")
	public ResponseEntity<MediaDetailsModel>getAllById(@PathVariable Integer userId){
		
		ResponseEntity<List<MediaData>> media = this.proxy.getMediaByUserId(userId);
		
		List<GalleryDisplayResponse> filelist = new ArrayList<GalleryDisplayResponse>();
		
		logger.info("user id : => : "+userId);
		logger.info("List : " + media.getBody());
		for(MediaData data : media.getBody()) {	
			
			CommentsNumberModel commentsCount =  this.commentServiceProxy.getCountById(data.getMediaId()).getBody();
			
			Integer comments = 0;
			if(commentsCount !=null) {
				comments = commentsCount.getComments();
			}
			Integer likes = this.actionServiceProxy.getLikesAndDislikes(data.getMediaId()).getBody().getLikes();
			Integer dislikes = this.actionServiceProxy.getLikesAndDislikes(data.getMediaId()).getBody().getDislikes();
			//CommentNumberModel commentNumberModel = this.commentServiceProxy.getCountById(data.getId()).getBody();
			//System.out.println(commentNumberModel.getComments());
			
			GalleryDisplayResponse response = new GalleryDisplayResponse(data.getMediaId(), data.getUserId(), data.getTitle(), data.getDescription(), data.getTag(), data.getMimeType(), data.getFileUrl(),comments,likes,dislikes);
			filelist.add(response);
		}
		
		MediaDetailsModel resultlist = new MediaDetailsModel();
		resultlist.setFilelist(filelist);
		ResponseEntity<MediaDetailsModel> result = new ResponseEntity<MediaDetailsModel>(resultlist,HttpStatus.OK);	
		
		return result;
	}
	
	@GetMapping("/comment/{mediaId}")
	public ResponseEntity<CommentsNumberModel> getCommentsCount(@PathVariable Integer mediaId){
		ResponseEntity<CommentsNumberModel> count = this.commentServiceProxy.getCountById(mediaId);
		return count;
	}
	 
	 
}