package com.cts.training.mediaplumbingmicroservice.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GalleryDisplayResponse {
	private Integer madiaId;
	private Integer userId;
	private String title;
	private String description;
	private String tag;
	private String mimeType;
	private String fileUrl;
	private Integer comments;
	private Integer likes;
	private Integer dislikes;
	
	
	
}
