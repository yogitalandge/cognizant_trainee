package com.cts.training.mediaplumbingmicroservice.feignproxy;



import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaplumbingmicroservice.model.MediaData;
import com.cts.training.mediaplumbingmicroservice.model.MediaDataModel;
import com.cts.training.mediaplumbingmicroservice.model.MediaDetailsModel;
import com.cts.training.mediaplumbingmicroservice.model.MediaModel;


@FeignClient(name = "api-gateway", url="http://localhost:8765/") //, decode404 = true)
@RibbonClient(name = "media-services")
@Service
public interface IMediaMicroserviceProxy {

//	@GetMapping("media-service/media/{mediaId}")
//public ResponseEntity<MediaPlumbing> mediaDetail(@PathVariable Integer mediaId);

	@PostMapping(value = "/media-services/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file);
	
	@PostMapping(value = "/media-services/mediadata")
	public boolean saveData(@RequestBody MediaDataModel media);
	
	@GetMapping("/media-services/media/user/{userId}")
	public ResponseEntity<List<MediaData>>getMediaByUserId(@PathVariable Integer userId);
	
	@GetMapping("/media-services/media/{userId}")
	public ResponseEntity<MediaModel>getAllById(@PathVariable Integer userId);

	//@GetMapping("/media/{userId}")
	//public ResponseEntity<MediaDetailsModel>getAllById(@PathVariable Integer userId);
	//public ResponseEntity<MediaModel> getAllById(Integer userId);
	

}





