package com.cts.training.commentmicroservice.Controller;

import java.util.List;
import java.util.Optional;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.commentmicroservice.entity.Comment;
import com.cts.training.commentmicroservice.exception.CommentNotFoundException;
import com.cts.training.commentmicroservice.model.CommentsDataModel;
import com.cts.training.commentmicroservice.model.CommentsNumberModel;
import com.cts.training.commentmicroservice.service.ICommentService;







@RestController
public class CommentController {

	

	
	private Logger logger  = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ICommentService commentService;
	
	// @RequestMapping(value =  "/students", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/comment") // GET HTTP VERB
	public ResponseEntity<List<Comment>> exposeAll() {
		
		List<Comment> comment = this.commentService.findAllComment();
		ResponseEntity<List<Comment>> response = 
								new ResponseEntity<List<Comment>>(comment, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
/*	@GetMapping("/comment/{commentId}") // GET HTTP VERB
	public ResponseEntity<Comment> getById(@PathVariable Integer commentId) {
		
		Comment comment = this.commentService.findCommentById(commentId);
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	*/
	@GetMapping("/comment/{commentId}")
	public ResponseEntity<CommentsDataModel> getById(@PathVariable Integer commentId){
		CommentsDataModel data = new CommentsDataModel();
		Comment record = new Comment();
		Optional<Comment> comment = this.commentService.getWithId(commentId);
		if(comment.isPresent())
			record = comment.get();
		else {
			throw new CommentNotFoundException("comment not found");
		}
		data.setComments(record.getComments());
		data.setCommentId(record.getCommentId());
		data.setCreatedOn(record.getCreatedOn());
		data.setUserId(record.getUserId());
		data.setMediaId(record.getMediaId());
		ResponseEntity<CommentsDataModel> result = new ResponseEntity<CommentsDataModel>(data, HttpStatus.OK);
		return result;
	}
	
	// @RequestMapping(value =  "/students", method = RequestMethod.POST)
	@PostMapping("/comment") // POST HTTP VERB
	public ResponseEntity<Comment> save(@RequestBody Comment comment) {
		this.commentService.addComment(comment);
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/comment")
	public boolean update(@RequestBody CommentsDataModel user) {
		
		this.commentService.updateuser(user);
		return true;
		
	}
	@GetMapping("/getcount/{mediaId}")
	public ResponseEntity<CommentsNumberModel> getCountById(@PathVariable Integer mediaId) {
		
		CommentsNumberModel data = this.commentService.getCountById(mediaId);
		
		ResponseEntity<CommentsNumberModel> result = 
									new ResponseEntity<CommentsNumberModel>(data, HttpStatus.OK);
		logger.info("result in comment controller : "+data);
		return result;
		
	}
	
/*	@DeleteMapping("/comment/{commentId}")
	public ResponseEntity<Comment> delete(@PathVariable Integer commentId) {
		
		Comment comment = this.commentService.findCommentById(commentId);
		this.commentService.deleteComment(commentId);
		
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	*/
}


