package com.cts.training.commentmicroservice.custom;

import com.cts.training.commentmicroservice.model.CommentsNumberModel;

public interface ICountCustomRespository {
	
	CommentsNumberModel findCountById(Integer mediaId);

}