package com.cts.training.commentmicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cts.training.commentmicroservice.Repository.ICommentRepository;
import com.cts.training.commentmicroservice.custom.ICountCustomRespository;
import com.cts.training.commentmicroservice.entity.Comment;
import com.cts.training.commentmicroservice.model.CommentsDataModel;
import com.cts.training.commentmicroservice.model.CommentsNumberModel;







// @Component
@Service
public class CommentServiceImpl implements ICommentService {

	@Autowired
	private ICommentRepository commentRepository;
	
	@Autowired 
	private ICountCustomRespository countCustomRepository;


	@Override
	public List<Comment> findAllComment() {
		List<Comment> records = this.commentRepository.findAll();
		return records;
	}

	@Override
	public void save(CommentsDataModel comment) {
Comment data = new Comment();
		
		data.setComments(comment.getComments());
		data.setUserId(comment.getUserId());
		data.setMediaId(comment.getMediaId());
		
		this.commentRepository.save(data);
		
		
	}
	
	@Override
	public Optional<Comment> findCommentById(Integer commentId) {
		Optional<Comment> record= this.commentRepository.findById(commentId);
		return record;
		
	}

/*	@Override
	public Comment findCommentById(Integer commentId) {
		// TODO Auto-generated method stub
		 this.commentRepository.findById(commentId);
		
		Optional<Comment> record= this.commentRepository.findById(commentId);
		Comment comment = new Comment();
		if(record.isPresent())
			comment=record.get();
		return comment;
	}*/

	@Override
	public boolean addComment(Comment comment) {
		// TODO Auto-generated method stub
		 this.commentRepository.save(comment);
		return true;
	}

	

	@Override
	public boolean deleteComment(Integer commentId) {
		// TODO Auto-generated method stub
		 this.commentRepository.deleteById(commentId);
		return true;
	}

	@Override
	public void updateuser(CommentsDataModel comment) {
		// TODO Auto-generated method stub
		Comment data = new Comment();
		data.setCommentId(comment.getCommentId());
		data.setComments(comment.getComments());
		data.setUserId(comment.getUserId());
		data.setMediaId(comment.getMediaId());
		data.setCreatedOn(comment.getCreatedOn());
		this.commentRepository.save(data);
	}

	@Override
	public CommentsNumberModel getCountById(Integer mediaId) {
		
			CommentsNumberModel commentsNumberModel =  this.countCustomRepository.findCountById(mediaId);
			return commentsNumberModel;
		}

	@Override
	public Optional<Comment> getWithId(Integer id) {
		// TODO Auto-generated method stub
		return null;
	} 
	}


