package com.cts.training.commentmicroservice.service;

import java.util.List;
import java.util.Optional;

import com.cts.training.commentmicroservice.entity.Comment;
import com.cts.training.commentmicroservice.model.CommentsDataModel;
import com.cts.training.commentmicroservice.model.CommentsNumberModel;


public interface ICommentService {

	
	public List<Comment> findAllComment();
	//Comment findCommentById(Integer commentId);
	public void save(CommentsDataModel comment);
	boolean addComment(Comment comment);
	public Optional<Comment> getWithId(Integer commentId);
	public Optional<Comment> findCommentById(Integer commentId);
	public void updateuser(CommentsDataModel comment);
	//boolean updateComment(Comment comment);
	boolean deleteComment(Integer commentId);
	public CommentsNumberModel getCountById(Integer mediaId);
}
/*
 public List<Comments> getall();
	public void save(CommentsDataModel comment);
	public Optional<Comments> getWithId(Integer id);
	public void updateuser(CommentsDataModel action);
	public CommentsNumberModel getCountById(Integer mediaid);
 */
