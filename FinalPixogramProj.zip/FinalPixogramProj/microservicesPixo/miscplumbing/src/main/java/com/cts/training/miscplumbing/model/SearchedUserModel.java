package com.cts.training.miscplumbing.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SearchedUserModel {
	private Integer userId;
	private String name;
	private String profilepic;
	private Boolean followed;
}
