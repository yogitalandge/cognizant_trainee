import { ɵLocaleDataIndex } from '@angular/core';

export class UserRegistrationDetails{


    userId:number;
    username:string;
    password:string;
    firstName:string;
    lastName:string;
    email:string;
    
    profilepic:string;


    constructor(
        username:string,
        password:string,
        firstName:string,
        lastName:string,
        email:string,

        profilepic:string)
        {
            this.username=username;
            this.password=password;
            this.email=email;
            this.lastName=lastName;
            this.firstName=firstName;
            
            this.profilepic=profilepic;
        }

}