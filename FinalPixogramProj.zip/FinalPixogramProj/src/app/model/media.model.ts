export class Media{
    

      //userId: number;
    mediaId : number ;
    fileUrl : string;
    title : string;
    description : string;
    tag : string;
     constructor(title,description,tag,fileUrl){
         
        
         this.title = title;
         this.description = description;
         this.tag = tag;
         this.fileUrl = fileUrl ;
     }
}