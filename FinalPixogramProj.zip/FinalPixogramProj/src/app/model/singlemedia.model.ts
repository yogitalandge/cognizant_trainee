export class SingleMedia{
    userId:number;
    title:string;
    description:string;
    mimeType:String;
    fileUrl:string;
    tag:string;
    likes:number;
    dislikes:number;
    commentcount:number;
}