import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpEvent, HttpClient, HttpRequest } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {
  baseUrl : string ="http://localhost:8765/user-service/register";

  constructor(private http: HttpClient, public auth : AuthenticationService) { }
  pushFileToStorage(file: File,  profilepic, username, password,email,firstName,lastName) : Observable<HttpEvent<{}>>{
    
    const formdata: FormData = new FormData();
    console.log("storing..")
    // let product = new  Product (name,category,cost,file,url);
    formdata.append('file', file, profilepic);
    //formdata.append('userId', this.auth.getUserId());
    formdata.append('profilepic', profilepic);
    formdata.append('username', username);
    formdata.append('password', password);
    formdata.append('email', email);
    formdata.append('firstName', firstName);
    formdata.append('lastName',lastName);

    // header info to set for responding the progress report
    /*return this.http.post(this.baseUrl, formdata,{
      reportProgress: true,
      responseType: 'text'
    });*/

    const req = new HttpRequest('POST', `${this.baseUrl}`, formdata)
     // reportProgress: true,
     // responseType: 'text'

    

    return this.http.request(req);
  }
}
