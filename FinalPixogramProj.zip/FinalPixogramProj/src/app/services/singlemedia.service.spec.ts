import { TestBed } from '@angular/core/testing';

import { SinglemediaService } from './singlemedia.service';

describe('SinglemediaserviceService', () => {
  let service: SinglemediaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SinglemediaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
