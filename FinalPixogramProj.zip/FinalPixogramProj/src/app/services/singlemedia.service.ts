import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { Observable } from 'rxjs';
import { SingleMedia } from '../model/singlemedia.model';

@Injectable({
  providedIn: 'root'
})
export class SinglemediaService {
URL="http://localhost:8765/media-plumbing/media"

  constructor(public http:HttpClient,public auth:AuthenticationService) { }
    getAllSingleMedia():Observable<SingleMedia[]>
    {
      return this.http.get<SingleMedia[]>(this.URL+"/"+sessionStorage.getItem("userId"));
    //  return this.http.get<SingleMedia[]>(this.URL+this.auth.getUserId);
    }
  
  }
