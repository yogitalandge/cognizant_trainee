import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Media } from 'src/app/model/media.model';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MediaserviceService } from 'src/app/services/mediaservice.service';

@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {

  title: string;
  description : string;
  tag : string;
  fileUrl : string
  myFormGroup : FormGroup;
  selectedFiles: FileList;
  selectedFile : File;
  date : Date;

  constructor(public formBuilder: FormBuilder, public mediaService : MediaserviceService,public router : Router ) {
    console.log("in form bilder of single media");
    this.myFormGroup=formBuilder.group({
      "title":new FormControl("",Validators.required),
      "description":new FormControl(""),
      "tag":new FormControl("")
    });

  }
  onImageLoad(event){
  this.selectedFiles = event.target.files;
  this.selectedFile = this.selectedFiles.item(0);
}
mediaDetails(){
    console.log("Single Media Details method");
    this.title= this.myFormGroup.controls['title'].value;
    this.description=this.myFormGroup.controls['description'].value;
    this.tag=this.myFormGroup.controls['tag'].value;
    this.date=new Date();
    let dateString = `_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
    if (this.selectedFile.type == 'image/png') {
      this.fileUrl = `${this.title}${dateString}.png`;
    }
    if (this.selectedFile.type == 'image/jpeg' || this.selectedFile.type == 'image/jpg') {
      this.fileUrl = `${this.title}${dateString}.jpeg`;
    }
  
    console.log(this.fileUrl+"\n"+this.title+"\n"+this.description+"\n"+this.tag);
    let uploadfile = new Media(this.fileUrl,this.title,this.description,this.tag)

    this.mediaService.pushFileToStorage(this.selectedFile,this.title,this.description,this.tag,this.fileUrl,this.selectedFile.type).subscribe(
      (responce)=>{this.router.navigate(['/media/'])});
  }
message(){
  alert("you have uploaded the media")
}
  ngOnInit() {
    
  }

 // add(){
    // navigate to media-add component
   // this.router.navigate(['/multiplemedia']);
 // }

}
