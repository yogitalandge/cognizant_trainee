import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user-registration.service';
import { SearchedUser } from 'src/app/model/searcheduser.model';
import { SearchedUserlList } from 'src/app/model/searcheduserlist.model';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchtext : string;
  myFormGroup : FormGroup;
  result : string ;
  userList : Array<SearchedUser>;

  constructor(formbuilder : FormBuilder, public router: Router, private userService: UserRegistrationService) {
    
    this.myFormGroup = formbuilder.group(
      {
        "keyword" : new FormControl(),
      }
    );

   }

   search(){
     this.searchtext = this.myFormGroup.controls['keyword'].value;
     this.userService.getSearchedUsers(this.searchtext).subscribe(
      (response : SearchedUserlList) => {
        this.userList = response.userList;
        this.userList = this.userList.map(user =>{
          user.profilepic = "http://localhost:8765/user-service/"+user.profilepic;
          return user;
        });
        
      }
    );
   }

   

  ngOnInit() {
  }

}
