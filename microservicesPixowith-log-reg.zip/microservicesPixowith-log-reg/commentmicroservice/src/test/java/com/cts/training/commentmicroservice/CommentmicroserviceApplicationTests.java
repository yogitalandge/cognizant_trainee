package com.cts.training.commentmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
