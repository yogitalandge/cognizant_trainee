package com.cts.training.usermicroservice.model;

import java.util.List;

import com.cts.training.usermicroservice.entity.User;

public class DataModel {

	public List<User> user;
}
