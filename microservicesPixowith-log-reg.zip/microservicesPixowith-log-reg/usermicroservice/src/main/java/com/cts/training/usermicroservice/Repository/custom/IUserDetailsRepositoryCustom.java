package com.cts.training.usermicroservice.Repository.custom;

public interface IUserDetailsRepositoryCustom {

}
