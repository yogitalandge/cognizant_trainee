package com.cts.training.newsfeedmicroservice.Controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.newsfeedmicroservice.Repository.NewsfeedRepository;
import com.cts.training.newsfeedmicroservice.entity.Newsfeed;
@RestController
public class NewsfeedController {

	
	
	private Logger logger  = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private Environment env;
	// dependency
	@Autowired
	private NewsfeedRepository newsfeedRepository;
	
	@GetMapping("/newsfeed/{newsfeedId}")
	public ResponseEntity<Newsfeed> newsfeedDetail(@PathVariable Integer newsfeedId){
		Optional<Newsfeed> record =  this.newsfeedRepository.findById(newsfeedId);
		Newsfeed newsfeed = new Newsfeed();
		
		if(record.isPresent()) {
			newsfeed = record.get();
			this.logger.info("Record found");
		}
		String port =  env.getProperty("server.port");
		this.logger.info("Newsfeed :" +newsfeed);
		newsfeed.setFeed(newsfeed.getFeed() + " (" + port + ")");	
		ResponseEntity<Newsfeed> response = new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);
		return response;
		
	}
	
	
}
