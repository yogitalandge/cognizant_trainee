package com.cts.training.newsfeedmicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.newsfeedmicroservice.entity.Newsfeed;

public interface NewsfeedRepository extends JpaRepository<Newsfeed, Integer> {

}
