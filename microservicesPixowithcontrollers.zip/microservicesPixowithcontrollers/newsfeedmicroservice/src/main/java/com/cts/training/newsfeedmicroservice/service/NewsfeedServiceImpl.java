package com.cts.training.newsfeedmicroservice.service;

public class NewsfeedServiceImpl {

}
