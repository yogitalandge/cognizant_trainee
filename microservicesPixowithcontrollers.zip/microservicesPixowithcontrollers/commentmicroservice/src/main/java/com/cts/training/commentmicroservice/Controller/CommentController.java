package com.cts.training.commentmicroservice.Controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.commentmicroservice.Repository.CommentRepository;
import com.cts.training.commentmicroservice.entity.Comment;


public class CommentController {
	
	
	@Autowired
	private Environment env;
	// dependency
	@Autowired
	private CommentRepository commentRepository;
	

	
		
		private Logger logger  = LoggerFactory.getLogger(this.getClass());
		
		
		@GetMapping("/comment/{commentId}")
		public ResponseEntity<Comment> commentDetail(@PathVariable Integer commentId){
			Optional<Comment> record =  this.commentRepository.findById(commentId);
			Comment comment = new Comment();
			
			if(record.isPresent()) {
				comment = record.get();
				this.logger.info("Record found");
			}
			String port =  env.getProperty("server.port");
			this.logger.info("Comment :" +comment);
			comment.setComment(comment.getComment() + " (" + port + ")");
			ResponseEntity<Comment> response = new ResponseEntity<Comment>(comment, HttpStatus.OK);
			return response;
			
		}
	
}
