package com.cts.training.mediamicroservice.service;

public interface IMediaService {

}
