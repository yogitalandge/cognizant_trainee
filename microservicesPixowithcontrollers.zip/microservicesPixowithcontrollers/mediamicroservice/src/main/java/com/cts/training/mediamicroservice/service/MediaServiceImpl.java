package com.cts.training.mediamicroservice.service;

public class MediaServiceImpl {

}
