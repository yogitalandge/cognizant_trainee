package com.cts.training.usermicroservice.Controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.usermicroservice.Repository.UserRepository;
import com.cts.training.usermicroservice.entity.User;




@RestController
public class UserController {

	
	//private Logger logger  = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private Environment env;
	// dependency
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/user/{userId}")
	public ResponseEntity<User> userDetail(@PathVariable Integer userId){
		Optional<User> record =  this.userRepository.findById(userId);
		User user = new User();
		
		if(record.isPresent()) {
			user = record.get();
			//this.logger.info("Record found");
		}
		String port =  env.getProperty("server.port");
		//this.logger.info("User :" +user);
		user.setUserName(user.getUserName() + " (" + port + ")");
		ResponseEntity<User> response = new ResponseEntity<User>(user, HttpStatus.OK);
		return response;
		
	}
}












