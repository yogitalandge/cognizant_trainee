package com.cts.training.usermicroservice.service;

public class UserServiceImpl {

}
