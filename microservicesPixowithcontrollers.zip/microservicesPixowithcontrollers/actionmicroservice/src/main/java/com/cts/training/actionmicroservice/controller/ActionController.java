package com.cts.training.actionmicroservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.actionmicroservice.Repository.ActionRepository;
import com.cts.training.actionmicroservice.entity.Action;


@RestController
public class ActionController {

	
	
	

		
		private Logger logger  = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private Environment env;
		// dependency
		@Autowired
		private ActionRepository actionRepository;
		
		@GetMapping("/action/{actionId}")
		public ResponseEntity<Action> actionDetail(@PathVariable Integer actionId){
			Optional<Action> record =  this.actionRepository.findById(actionId);
			Action action = new Action();
			
			if(record.isPresent()) {
				action = record.get();
				this.logger.info("Record found");
			}
			String port =  env.getProperty("server.port");
			this.logger.info("Media :" +action);
			action.setAction(action.getAction() + " (" + port + ")");
			ResponseEntity<Action> response = new ResponseEntity<Action>(action, HttpStatus.OK);
			return response;
			
		}
	
	
}
