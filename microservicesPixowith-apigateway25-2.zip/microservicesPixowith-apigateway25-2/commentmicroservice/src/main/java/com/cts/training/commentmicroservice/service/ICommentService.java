package com.cts.training.commentmicroservice.service;

import java.util.List;

import com.cts.training.commentmicroservice.entity.Comment;


public interface ICommentService {

	
	List<Comment> findAllComment();
	Comment findCommentById(Integer commentId);
	boolean addComment(Comment comment);
	boolean updateComment(Comment comment);
	boolean deleteComment(Integer commentId);
}
