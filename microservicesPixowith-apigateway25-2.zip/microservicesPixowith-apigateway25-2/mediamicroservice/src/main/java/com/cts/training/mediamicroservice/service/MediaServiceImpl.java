package com.cts.training.mediamicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.mediamicroservice.Repository.IMediaRepository;
import com.cts.training.mediamicroservice.entity.Media;





// @Component
@Service
public class MediaServiceImpl implements IMediaService {

	
	
	@Autowired
	private IMediaRepository mediaRepository;
	
	@Override
	public List<Media> findAllMedia() {
		// add additional logic
		return this.mediaRepository.findAll();
	}

	@Override
	public Media findMediaById(Integer mediaId) {
		// TODO Auto-generated method stub
		//return this.userRepository.findById(userId);
		
		Optional<Media> record= this.mediaRepository.findById(mediaId);
		Media media = new Media();
		if(record.isPresent())
			media=record.get();
		return media;
	}

	@Override
	public boolean addMedia(Media media) {
		// TODO Auto-generated method stub
		 this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean updateMedia(Media media) {
		// TODO Auto-generated method stub
		 this.mediaRepository.save(media);
		return true;
	}

	@Override
	public boolean deleteMedia(Integer mediaId) {
		// TODO Auto-generated method stub
		 this.mediaRepository.deleteById(mediaId);
		return true;
	}

}
