package com.cts.training.mediamicroservice.service;

import java.util.List;

import com.cts.training.mediamicroservice.entity.Media;


public interface IMediaService {

	

	List<Media> findAllMedia();
	Media findMediaById(Integer mediaId);
	boolean addMedia(Media media);
	boolean updateMedia(Media media);
	boolean deleteMedia(Integer mediaId);
}
