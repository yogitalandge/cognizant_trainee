package com.cts.training.usermicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.usermicroservice.Repository.IUserRepository;
import com.cts.training.usermicroservice.entity.User;



// @Component
@Service
public class UserServiceImpl implements IUserService {



	@Autowired
	private IUserRepository userRepository;
	
	@Override
	public List<User> findAllUsers() {
		// add additional logic
		return this.userRepository.findAll();
	}

	@Override
	public User findUserById(Integer userId) {
		// TODO Auto-generated method stub
		//return this.userRepository.findById(userId);
		
		Optional<User> record= this.userRepository.findById(userId);
		User user = new User();
		if(record.isPresent())
			user=record.get();
		return user;
	}

	@Override
	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		 this.userRepository.save(user);
		return true;
	}

	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		 this.userRepository.save(user);
		return true;
	}

	@Override
	public boolean deleteUser(Integer userId) {
		// TODO Auto-generated method stub
		this.userRepository.deleteById(userId);
		return true;
	}

}
