package com.cts.training.usermicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.usermicroservice.entity.User;

public interface IUserRepository extends JpaRepository<User, Integer> {

}
