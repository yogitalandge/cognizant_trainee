package com.cts.training.newsfeedmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsfeedmicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
