package com.cts.training.newsfeedmicroservice.exception;

public class NewsfeedNotFoundException extends RuntimeException {

	
	public NewsfeedNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
