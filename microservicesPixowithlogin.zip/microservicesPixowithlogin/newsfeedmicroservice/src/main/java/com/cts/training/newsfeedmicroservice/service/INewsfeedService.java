package com.cts.training.newsfeedmicroservice.service;

import java.util.List;


import com.cts.training.newsfeedmicroservice.entity.Newsfeed;

public interface INewsfeedService {

	
	List<Newsfeed> findAllNewsfeed();
	Newsfeed findNewsfeedById(Integer newsfeedId);
	boolean addNewsfeed(Newsfeed newsfeed);
	boolean updateNewsfeed(Newsfeed newsfeed);
	boolean deleteNewsfeed(Integer newsfeedId);
}
