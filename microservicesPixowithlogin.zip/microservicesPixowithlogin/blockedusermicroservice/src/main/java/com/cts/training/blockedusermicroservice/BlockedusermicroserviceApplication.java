package com.cts.training.blockedusermicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockedusermicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockedusermicroserviceApplication.class, args);
	}

}
