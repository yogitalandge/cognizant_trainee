package com.cts.training.usermicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.usermicroservice.Repository.custom.IAuthorityRepositoryCustom;
import com.cts.training.usermicroservice.entity.Roles;


@Repository
public interface IAuthorityRepository extends JpaRepository<Roles, Integer>,IAuthorityRepositoryCustom{

	

}
