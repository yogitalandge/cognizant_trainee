package com.cts.training.mediaplumbingmicroservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediaplumbingmicroservice.feignproxy.IMediaMicroserviceProxy;
import com.cts.training.mediaplumbingmicroservice.model.MediaDataModel;

@CrossOrigin("*")
@RestController
public class MediaPlumbingController {

	@Autowired
	private IMediaMicroserviceProxy proxy;


	private final String MEDIA_URL = "http://localhost:9094";
  Logger logger= LoggerFactory.getLogger(this.getClass());
 
	
	@PostMapping(value = "/media") // POST HTTP VERB
	public void post(@RequestParam("file") MultipartFile file,
			@RequestParam("userId") String userId,
			@RequestParam("mimeType")String mimeType,
			@RequestParam("fileUrl")String fileUrl,
			@RequestParam("title")String title,
			@RequestParam("description")String description, 
			@RequestParam("tag")String tag)
	{
 logger.info("userId"+userId+ ""+fileUrl+ ""+mimeType+""+title+""+description+""+tag+"");
		//User user = new User();
		MediaDataModel media =new MediaDataModel(Integer.parseInt(userId), fileUrl,title,description,tag,mimeType);
 // ResponseEntity<MediaPlumbingData> response = 
			//new ResponseEntity<MediaPlumbingData>( HttpStatus.OK);
		
			boolean b = this.proxy.saveData(media);
			boolean a = this.proxy.save(file);
			
			
	
	}
	
}