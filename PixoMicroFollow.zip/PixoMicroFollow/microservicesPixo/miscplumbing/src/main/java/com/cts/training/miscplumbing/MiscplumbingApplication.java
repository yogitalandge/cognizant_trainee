package com.cts.training.miscplumbing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
@EnableEurekaClient
@EnableFeignClients("com.cts.training.miscplumbing.feignproxy")
@SpringBootApplication
public class MiscplumbingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiscplumbingApplication.class, args);
	}

}
