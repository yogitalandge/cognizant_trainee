package com.cts.training.miscplumbing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiscplumbingApplicationTests {

	@Test
	void contextLoads() {
	}

}
