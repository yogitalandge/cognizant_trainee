package com.cts.training.newsfeedmicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.newsfeedmicroservice.Repository.INewsfeedRepository;
import com.cts.training.newsfeedmicroservice.entity.Newsfeed;





// @Component
@Service
public class NewsfeedServiceImpl implements INewsfeedService {

	
	
	@Autowired
	private INewsfeedRepository newsfeedRepository;
	
	@Override
	public List<Newsfeed> findAllNewsfeed() {
		// add additional logic
		return this.newsfeedRepository.findAll();
	}

	@Override
	public Newsfeed findNewsfeedById(Integer newsfeedId) {
		// TODO Auto-generated method stub
		//return this.userRepository.findById(userId);
		
		Optional<Newsfeed> record= this.newsfeedRepository.findById(newsfeedId);
		Newsfeed newsfeed = new Newsfeed();
		if(record.isPresent())
			newsfeed=record.get();
		return newsfeed;
	}

	@Override
	public boolean addNewsfeed(Newsfeed newsfeed) {
		// TODO Auto-generated method stub
		 this.newsfeedRepository.save(newsfeed);
		return true;
	}

	@Override
	public boolean updateNewsfeed(Newsfeed newsfeed) {
		// TODO Auto-generated method stub
		 this.newsfeedRepository.save(newsfeed);
		return true;
	}

	@Override
	public boolean deleteNewsfeed(Integer newsfeedId) {
		// TODO Auto-generated method stub
		 this.newsfeedRepository.deleteById(newsfeedId);
		return true;
	}

}
