package com.cts.training.commentmicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.cts.training.commentmicroservice.Repository.ICommentRepository;
import com.cts.training.commentmicroservice.entity.Comment;







// @Component
@Service
public class CommentServiceImpl implements ICommentService {

	@Autowired
	@Qualifier("commentRepositoryHibernateImpl")
	
	private ICommentRepository commentRepository;
	
	@Override
	public List<Comment> findAllComment() {
		// add additional logic
		return this.commentRepository.findAll();
	}

	@Override
	public Comment findCommentById(Integer commentId) {
		// TODO Auto-generated method stub
		 this.commentRepository.findById(commentId);
		
		Optional<Comment> record= this.commentRepository.findById(commentId);
		Comment comment = new Comment();
		if(record.isPresent())
			comment=record.get();
		return comment;
	}

	@Override
	public boolean addComment(Comment comment) {
		// TODO Auto-generated method stub
		 this.commentRepository.save(comment);
		return true;
	}

	@Override
	public boolean updateComment(Comment comment) {
		// TODO Auto-generated method stub
		 this.commentRepository.save(comment);
		return true;
	}

	@Override
	public boolean deleteComment(Integer commentId) {
		// TODO Auto-generated method stub
		 this.commentRepository.deleteById(commentId);
		return true;
	}

}
