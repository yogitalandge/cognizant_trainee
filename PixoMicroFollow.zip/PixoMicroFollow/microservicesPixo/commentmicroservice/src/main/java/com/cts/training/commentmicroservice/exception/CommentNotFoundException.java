package com.cts.training.commentmicroservice.exception;

public class CommentNotFoundException extends RuntimeException {

	public CommentNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
