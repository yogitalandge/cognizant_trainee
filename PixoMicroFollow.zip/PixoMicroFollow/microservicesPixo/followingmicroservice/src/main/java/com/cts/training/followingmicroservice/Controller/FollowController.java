package com.cts.training.followingmicroservice.Controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;

import com.cts.training.followingmicroservice.Repository.FollowRepository;



@RestController
public class FollowController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private FollowRepository followRepository;
	
	/*@Autowired
	private IFollowService followService;
	*/
	@GetMapping("/check-followings/mine/{mineId}/other/{otherId}")
	public ResponseEntity<Boolean> getFollowingStatus(@PathVariable Integer mineId, @PathVariable Integer otherId){
		
		Boolean status = this.followRepository.checkFollowing(mineId, otherId);
		ResponseEntity<Boolean> result = new ResponseEntity<Boolean>(status,HttpStatus.OK);
		return result;
		
	}
	/*
	@GetMapping("/follow")
	public ResponseEntity<FollowModel> getallfollows(){
		FollowModel data = new FollowModel();
		data.setFollowlist(this.followService.getall());
		ResponseEntity<FollowModel> result = new ResponseEntity<FollowModel>(data,HttpStatus.OK);
		return result;
		
	}
	
	@PostMapping("/follow")
	public Boolean save(@RequestBody FollowData follow)
	{
		this.followService.save(follow);
		return true;
	}*/

}
