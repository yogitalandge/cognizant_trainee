package com.cts.training.followingmicroservice.exception;


public class FollowNotFoundException extends RuntimeException{
	
	
	private static final long serialVersionUID = 1L;

	public FollowNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
