package com.cts.training.followingmicroservice.model;


import java.util.List;

import com.cts.training.followingmicroservice.entity.Follow;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FollowModel {
	
	public List<Follow> followlist;
}
