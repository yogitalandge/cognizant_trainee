package com.cts.training.usermicroservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.training.usermicroservice.Repository.IAuthorityRepository;
import com.cts.training.usermicroservice.Repository.custom.IAuthorityRepositoryCustom;
import com.cts.training.usermicroservice.entity.Roles;

@Service
public class AuthorityService {
	
@Autowired
	private IAuthorityRepository authorityRepository;
	
public void saveauthority(Roles role) {
	
	this.authorityRepository.save(role);
}

}
