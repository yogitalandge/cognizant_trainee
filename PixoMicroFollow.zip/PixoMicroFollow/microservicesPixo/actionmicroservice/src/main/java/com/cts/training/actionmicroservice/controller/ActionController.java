package com.cts.training.actionmicroservice.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.actionmicroservice.entity.Action;
import com.cts.training.actionmicroservice.service.IActionService;







@RestController
public class ActionController {

	
	
	private Logger logger  = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IActionService actionService;
	
	// @RequestMapping(value =  "/students", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/action") // GET HTTP VERB
	public ResponseEntity<List<Action>> exposeAll() {
		
		List<Action> action = this.actionService.findAllAction();
		ResponseEntity<List<Action>> response = 
								new ResponseEntity<List<Action>>(action, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/comment/{commentId}") // GET HTTP VERB
	public ResponseEntity<Action> getById(@PathVariable Integer actionId) {
		
		Action action = this.actionService.findActionById(actionId);
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/students", method = RequestMethod.POST)
	@PostMapping("/comment") // POST HTTP VERB
	public ResponseEntity<Action> save(@RequestBody Action action) {
		this.actionService.addAction(action);
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/action")
	public ResponseEntity<Action> saveUpdate(@RequestBody Action action) {
		this.actionService.updateAction(action);
			
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/action/{actionId}")
	public ResponseEntity<Action> delete(@PathVariable Integer actionId) {
		
		Action action = this.actionService.findActionById(actionId);
		this.actionService.deleteAction(actionId);
		
		ResponseEntity<Action> response = 
				new ResponseEntity<Action>(action, HttpStatus.OK);

		return response;
	}
	
}


