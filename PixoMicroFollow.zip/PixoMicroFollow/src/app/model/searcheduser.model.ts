export class SearchedUser {
	userId : number;
	name : string;
	profilepic : string;
	followed : boolean;
}