export class Response{
    message:string;
    timestamp:number;
    userId:number;
}