import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { UserRegistrationService } from '../services/user-registration.service';
import { UploadFileService } from '../services/upload-file.service';
import { HttpEvent } from '@angular/common/http';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  
  username:string;
  password:string;
  email:string;
  firstName:string;
  lastName:string;
 profilepic: string;
 
  currentFileUpload: File;
  selectedFiles: FileList;
  date: Date;
 
  ngOnInit():void {
    this.username=this.auth.getUserDetails();
  
  }
form : FormGroup;
constructor(Formbuilder:FormBuilder, public router:Router,public auth :AuthenticationService,
  private uploadFileService:UploadFileService,public userService:UserRegistrationService) {
  this.form=Formbuilder.group({



    "userId": new FormControl(""),
    "username": new FormControl("",Validators.required),
    "password": new FormControl("",Validators.required),
    "email": new FormControl("",[Validators.required,Validators.email]),
    "firstName": new FormControl("",Validators.required),
    "lastName": new FormControl("",Validators.required),
   
    "profilepic": new FormControl("",Validators.required),
  });
}
selectFile(event){
  this.selectedFiles=event.target.files;
}
 
register():void{
  //console.log('hi reached')
  this.username=this.form.get('username').value;
  this.password=this.form.get('password').value;
  this.email=this.form.get('email').value;
  this.firstName=this.form.get('firstName').value;
  this.lastName=this.form.get('lastName').value;
  //.username=this.form.get('username').value;
  this.currentFileUpload=this.selectedFiles.item(0);
  this.date=new Date();
  let datestring=`_${this.date.getTime()}_${this.date.getDate()}_${this.date.getFullYear()}`
  if(this.currentFileUpload.type=='image/png'){
    this.profilepic= `${this.username}&{datestring}.png`;
  }

  if(this.currentFileUpload.type=='image/jpeg'||this.currentFileUpload.type=='image/jpg'){
    this.profilepic= `${this.username}&{datestring}.jpg`;
  }
  
 // this.userService.addNewUser(this.form.value).subscribe(data=>{
this.uploadFileService.pushFileToStorage(this.currentFileUpload,
                                  this.profilepic,this.username,
                                  this.password,this.email,
                                this.firstName,this.lastName).subscribe((event:HttpEvent<{}>)=>{

                                
   alert("Registered successfully...!!!");
    this.login();
  })
}
  
 login(): void{
   this.router.navigate(['login'])
 }  
 
 
//  onSubmit(){
 //   alert(JSON.stringify(this.form.value));
 // }

}
