import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import{map} from 'rxjs/operators';
import {Response} from '../model/ResponseModel.model';


const VALIDATION_URL = "http://localhost:8765/user-service/login";
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
 
  
  constructor(public http:HttpClient) { }

  //  check userid/pass and authenticate 
  /*authenticate(userid : string, password : string): boolean{
    // hard-coded validation
    if(userid === "Yogita" && password === "524"){
      //  need to maintain session
      // sessionStorage object is auto available
      sessionStorage.setItem("user", userid);
      return true;
    }else{
      return false;
    }
  }
*/


authenticate(username:string,password:string){

  let authenticationToken= "Basic " +window.btoa(username + ":"+password)
  console.log(authenticationToken);

let headers =new HttpHeaders({
  Authorization : authenticationToken
});
return this.http.get(VALIDATION_URL,{headers}).pipe(
  map((successData : Response)=>{
    sessionStorage.setItem("user",username);
    let response :Response = successData;
    
    sessionStorage.setItem("token",authenticationToken);
    sessionStorage.setItem("userId",response.userId + "");
   return successData; 
  }),
  map(failureData=>{
    return failureData;
  })
);

}
getAuthenticationToken(){
  if(this.isUserLoggedIn())
  return sessionStorage.getItem("token")
  return null;
}

  // to check if user if logged in or not
  isUserLoggedIn(): boolean{
    // check if sessionStorage contains key 'user'
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    return true;  
  }

  // logout
  logout(){
    // remove the key/value pair of 'user'
    sessionStorage.removeItem('user');
    sessionStorage.clear();
  }

  // get user Details
  getUserDetails():string{
    let user = sessionStorage.getItem('user');
    return user;
  }
  getUserId():string{
    let user = sessionStorage.getItem('userId');
    return user;
  }
  
}