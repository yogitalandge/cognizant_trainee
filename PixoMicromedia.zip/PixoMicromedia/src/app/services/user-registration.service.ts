import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from '../model/user-service';

const API_URL = "http://localhost:8765/user-service/user";

const BASIC_URL = "http://localhost:8765/user-service/register";
@Injectable({
  providedIn : "root"
})
export class UserRegistrationService {
  HTMLOutputElement: any;

  constructor(public http : HttpClient) { }
  getAllUsers()
  {
    return this.http.get(API_URL);
  }
  addNewUser(User : UserRegistrationDetails)
  {
    console.log('reached here')
    return this.http.post(BASIC_URL,User);
  }
  getOneUser(id:number)
  {
    return this.http.get(API_URL + "/" + id);  
  }
  updateUser(id: number ,user:UserRegistrationDetails)
  {
    return this.http.delete(API_URL + "/" + id); 
  }
  deleteUser(id:number)
  {
    return this.HTMLOutputElement.delete(API_URL + "/" + id);  
  }
}
