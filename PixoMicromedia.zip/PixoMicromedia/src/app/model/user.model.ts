export class User{
    userId: number;
    username : string;
    firstName : string;
    lastName: string;
    email: string;
    file: File ;
    profilepic:string;

    constructor(username:string, firstName:string, lastName:string,profilepic:string,email:string,file:File){
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.profilepic=profilepic;
        this.email=email;
        this.file=file;
    }
}