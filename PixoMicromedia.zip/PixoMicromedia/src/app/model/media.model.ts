export class Media{
    

      //userId: number;
    mediaId : number ;
    fileUrl : string;
    title : string;
    description : string;
    tag : string;
     constructor(fileUrl,title,description,tag){
         
         this.fileUrl = fileUrl ;
         this.title = title;
         this.description = description;
         this.tag = tag;
     }
}