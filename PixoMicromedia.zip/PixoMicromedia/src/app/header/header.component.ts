import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { UserRegistrationService } from '../services/user-registration.service';
import { UserRegistrationDetails } from '../model/user-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  user: UserRegistrationDetails;

  constructor(public auth:AuthenticationService , public userService:UserRegistrationService ) { }

  ngOnInit() {
this.userService.getOneUser(parseInt(this.auth.getUserId())).subscribe((response:UserRegistrationDetails)=>{
  this.user=response;
  this.user.profilepic="http://localhost:8765/user-service/"+this.user.profilepic;
});
  }

}
