package com.cts.training.newsfeedmicroservice.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.newsfeedmicroservice.Repository.INewsfeedRepository;
import com.cts.training.newsfeedmicroservice.entity.Newsfeed;
import com.cts.training.newsfeedmicroservice.service.INewsfeedService;
@RestController
public class NewsfeedController {

	
	

		
		
		private Logger logger  = LoggerFactory.getLogger(this.getClass());
		@Autowired
		private INewsfeedService newsfeedService;
		
		// @RequestMapping(value =  "/students", method = {RequestMethod.GET, RequestMethod.PUT} )
		@GetMapping("/newsfeed") // GET HTTP VERB
		public ResponseEntity<List<Newsfeed>> exposeAll() {
			
			List<Newsfeed> newsfeed = this.newsfeedService.findAllNewsfeed();
			ResponseEntity<List<Newsfeed>> response = 
									new ResponseEntity<List<Newsfeed>>(newsfeed, HttpStatus.OK);
			
			
			return response;
		}
		
		// {<data variable>}
		@GetMapping("/newsfeed/{newsfeedId}") // GET HTTP VERB
		public ResponseEntity<Newsfeed> getById(@PathVariable Integer newsfeedId) {
			
			Newsfeed newsfeed = this.newsfeedService.findNewsfeedById(newsfeedId);
			ResponseEntity<Newsfeed> response = 
					new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

			return response;
		}
		
		// @RequestMapping(value =  "/students", method = RequestMethod.POST)
		@PostMapping("/newsfeed") // POST HTTP VERB
		public ResponseEntity<Newsfeed> save(@RequestBody Newsfeed newsfeed) {
			this.newsfeedService.addNewsfeed(newsfeed);
			ResponseEntity<Newsfeed> response = 
					new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

			return response;
		}
		
		@PutMapping("/newsfeed")
		public ResponseEntity<Newsfeed> saveUpdate(@RequestBody Newsfeed newsfeed) {
			this.newsfeedService.updateNewsfeed(newsfeed);
				
			ResponseEntity<Newsfeed> response = 
					new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

			return response;
		}
		
		@DeleteMapping("/newsfeed/{newsfeedId}")
		public ResponseEntity<Newsfeed> delete(@PathVariable Integer newsfeedId) {
			
			Newsfeed newsfeed = this.newsfeedService.findNewsfeedById(newsfeedId);
			this.newsfeedService.deleteNewsfeed(newsfeedId);
			
			ResponseEntity<Newsfeed> response = 
					new ResponseEntity<Newsfeed>(newsfeed, HttpStatus.OK);

			return response;
		}
		
	}



	

