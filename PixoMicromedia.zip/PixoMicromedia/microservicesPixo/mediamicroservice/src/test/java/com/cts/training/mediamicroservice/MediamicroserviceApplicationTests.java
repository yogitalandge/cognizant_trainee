package com.cts.training.mediamicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediamicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
