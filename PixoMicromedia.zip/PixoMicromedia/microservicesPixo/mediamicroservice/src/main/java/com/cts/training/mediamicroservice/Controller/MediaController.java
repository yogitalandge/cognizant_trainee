package com.cts.training.mediamicroservice.Controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.mediamicroservice.entity.Media;
import com.cts.training.mediamicroservice.exception.MediaErrorResponse;
import com.cts.training.mediamicroservice.exception.MediaNotFoundException;
import com.cts.training.mediamicroservice.model.MediaData;
import com.cts.training.mediamicroservice.model.MediaModel;
import com.cts.training.mediamicroservice.model.MediaDataModel;
import com.cts.training.mediamicroservice.service.IMediaService;
import com.cts.training.mediamicroservice.service.StorageService;


@RestController
public class MediaController {

	
	private Logger logger  = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private IMediaService mediaService;
	
	@Autowired
	private StorageService storageService;
	
	// @RequestMapping(value =  "/students", method = {RequestMethod.GET, RequestMethod.PUT} )
/*	@GetMapping("/media") // GET HTTP VERB
	public ResponseEntity<MediaModel> exposeAll() {
		MediaModel medialist = new MediaModel();
		MediaModel.setMedialist = this.mediaService.findAllMedia();
		ResponseEntity<List<Media>> response = 
								new ResponseEntity<List<Media>>(media, HttpStatus.OK);
		
		
		return response;
	}*/
	
	@GetMapping("/media")
	public ResponseEntity<MediaModel> getall(){
		MediaModel medialist = new MediaModel();
		medialist.setMedialist(this.mediaService.findAllMedia());
		ResponseEntity<MediaModel> result = new ResponseEntity<MediaModel>(medialist, HttpStatus.OK);
		return result;
		
	}
	
	@PostMapping(value = "/media", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public boolean save(MultipartFile file) {
		this.storageService.store(file);
		//ResponseEntity<Boolean> response = new ResponseEntity<Boolean>(true, HttpStatus.OK);
		return true;
	}
	@PostMapping(value = "/mediadata")
	public boolean saveData(@RequestBody MediaDataModel media) {
		/*MediaData mediamod = new MediaData();
		mediamod.setTitle(media.getTitle());
		mediamod.setDescription(media.getDescription());
		mediamod.setTag(media.getTag());
		mediamod.setUserId(media.getUserId());
		mediamod.setFileUrl(media.getFileUrl());
		mediamod.setMimeType(media.getMimeType());*/
		this.mediaService.saveMedia(media);
		//this.storageService.store(file);
		
		return true;
	}
	@GetMapping("/media/{mediaId}")
	public ResponseEntity<MediaData> getById(@PathVariable Integer mediaId){
		MediaData data = new MediaData();
		Media record = new Media();
		Media media = this.mediaService.findMediaById(mediaId);
		/*if(media.isPresent())
			record = media.get();
		else {
			throw new MediaNotFoundException("Media not found");
		}
		data.setMediaId(record.getMediaId());
		data.setUserId(record.getUserId());
		data.setTitle(record.getTitle());
		data.setTag(record.getTag());
		data.setDescription(record.getDescription());
		data.setMimeType(record.getMimeType());
		data.setFileUrl(record.getFileUrl());
		*/
		ResponseEntity<MediaData> result =
				new ResponseEntity<MediaData>(data, HttpStatus.OK);
		return result;
	}
	//update user
	@PutMapping("/media")
	public boolean update(@RequestBody Media media) {
		
		this.mediaService.updateMedia(media);
		return true;
		}
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> commentNotFoundHandler(MediaNotFoundException ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.NOT_FOUND.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		
		return response;
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> commentOperationErrorHAndler(Exception ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
	
	

	
	
	/*
	// {<data variable>}
	@GetMapping("/media/{mediaId}") // GET HTTP VERB
	public ResponseEntity<Media> getById(@PathVariable Integer mediaId) {
		
		Media media = this.mediaService.findMediaById(mediaId);
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/students", method = RequestMethod.POST)
	@PostMapping("/media") // POST HTTP VERB
	public ResponseEntity<Media> save(@RequestBody Media media) {
		this.mediaService.addMedia(media);
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/media")
	public ResponseEntity<Media> saveUpdate(@RequestBody Media media) {
		this.mediaService.updateMedia(media);
			
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/media/{mediaId}")
	public ResponseEntity<Media> delete(@PathVariable Integer mediaId) {
		
		Media media = this.mediaService.findMediaById(mediaId);
		this.mediaService.deleteMedia(mediaId);
		
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}*/
	
}










