package com.cts.training.mediamicroservice.service;

import java.util.List;
import java.util.Optional;

import com.cts.training.mediamicroservice.entity.Media;
import com.cts.training.mediamicroservice.model.MediaData;
import com.cts.training.mediamicroservice.model.MediaDataModel;
import com.cts.training.mediamicroservice.model.MediaModel;


public interface IMediaService {

	

	List<Media> findAllMedia();
	Media findMediaById(Integer mediaId);
	boolean addMedia(Media media);
	boolean updateMedia(Media media);
	boolean deleteMedia(Integer mediaId);
	boolean saveMedia(MediaDataModel media);
	
//	public List<Media> getall();
//	boolean saveMedia(MediaData media);
//	public Optional<Media> getWithId(Integer id);
//	public void updateuser(MediaData action);
}
/*
 	
 	List<User> findAllUsers();
User findUserById(Integer userId);
boolean addUser(User user);
	boolean updateUser(User user);
	boolean deleteUser(Integer userId);
 public boolean saveuser(UserModel user);

 */
 