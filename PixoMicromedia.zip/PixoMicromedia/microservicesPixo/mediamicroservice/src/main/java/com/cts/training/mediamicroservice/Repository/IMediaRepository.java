package com.cts.training.mediamicroservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.mediamicroservice.entity.Media;

public interface IMediaRepository extends JpaRepository<Media, Integer> {

}
