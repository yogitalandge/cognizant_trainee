package com.cts.training.usermicroservice.Repository.custom;

public class AuthorityImpl {

}
