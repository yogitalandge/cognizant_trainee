package com.cts.training.actionmicroservice.service;

import java.util.List;

import com.cts.training.actionmicroservice.entity.Action;



public interface IActionService {

	
	List<Action> findAllAction();
	Action findActionById(Integer actionId);
	boolean addAction(Action action);
	boolean updateAction(Action action);
	boolean deleteAction(Integer actionId);
}
