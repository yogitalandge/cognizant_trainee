package com.cts.training.commentmicroservice.Controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.commentmicroservice.entity.Comment;
import com.cts.training.commentmicroservice.service.ICommentService;







@RestController
public class CommentController {

	
	
	private Logger logger  = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private ICommentService commentService;
	
	// @RequestMapping(value =  "/students", method = {RequestMethod.GET, RequestMethod.PUT} )
	@GetMapping("/comment") // GET HTTP VERB
	public ResponseEntity<List<Comment>> exposeAll() {
		
		List<Comment> comment = this.commentService.findAllComment();
		ResponseEntity<List<Comment>> response = 
								new ResponseEntity<List<Comment>>(comment, HttpStatus.OK);
		
		
		return response;
	}
	
	// {<data variable>}
	@GetMapping("/comment/{commentId}") // GET HTTP VERB
	public ResponseEntity<Comment> getById(@PathVariable Integer commentId) {
		
		Comment comment = this.commentService.findCommentById(commentId);
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	// @RequestMapping(value =  "/students", method = RequestMethod.POST)
	@PostMapping("/comment") // POST HTTP VERB
	public ResponseEntity<Comment> save(@RequestBody Comment comment) {
		this.commentService.addComment(comment);
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	@PutMapping("/comment")
	public ResponseEntity<Comment> saveUpdate(@RequestBody Comment comment) {
		this.commentService.updateComment(comment);
			
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	@DeleteMapping("/comment/{commentId}")
	public ResponseEntity<Comment> delete(@PathVariable Integer commentId) {
		
		Comment comment = this.commentService.findCommentById(commentId);
		this.commentService.deleteComment(commentId);
		
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
}


