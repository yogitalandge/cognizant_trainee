package com.cts.training.mediaplumbingmicroservice.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MediaDataModel {

	
	private Integer userId;

	private String title;

	private String description;

	private String mimeType;
	private String tag;
	
	private String fileUrl;

}
